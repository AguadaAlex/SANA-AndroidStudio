package com.example.sanapruebados;

public class daoEstablecimiento {
}
